package best.spring.framework.web;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Enumeration;
import java.util.Hashtable;

public class HttpPostGet {
	public static final String API_SERVER = "http://54.64.56.134:8080";
	public static final String LOGIN = "boratoon/web/game/login/user";
	public static final String SAVE_RESULT = "boratoon/web/game/reg/victroyhistory";
	public static final String VIEW_RESULT = "boratoon/web/game/view/victroyhistory";
	public static final String VIEW_APPOINT = "boratoon/web/event/view/selectEventPoint";
	public static final String ADD_APPOINT = "boratoon/web/event/receive/selectEventPoint";
	public static final String VIEW_NOTICE = "boratoon/web/board/notice";
	public static final String VIEW_BETLIST = "boratoon/web/game/view/betList";
	public static final String SAVE_USER_RESULT = "boratoon/web/game/reg/gameInfo";
	
	private Hashtable<String, Object> data = null;
	private URLConnection httpConn = null;
	private BufferedReader in = null;
	private PrintWriter out = null;
	private String ip = "";
	private URL url = null;
	
	private static HttpPostGet instance;
	public static HttpPostGet getInstance(){
		if (instance == null){
			instance = new HttpPostGet();
		}
		return instance; 
	}

	public HttpPostGet() {
		data = new Hashtable<String, Object>();
	}
	
	@SuppressWarnings("deprecation")
	public static String url_encoding(Hashtable<String, Object> hash) {
		if (hash == null)
			throw new IllegalArgumentException("argument is null");
		Enumeration<String> enum1 = hash.keys();
		StringBuffer buf = new StringBuffer();
		boolean isFirst = true;
		while (enum1.hasMoreElements()) {
			if (isFirst)
				isFirst = false;
			else
				buf.append('&');
			String key = (String) enum1.nextElement();
			String value = (String) hash.get(key);
			buf.append(java.net.URLEncoder.encode(key));
			buf.append('=');
			buf.append(java.net.URLEncoder.encode(value));
		}
		return buf.toString();
	}
	
	
	/**
	 * @param key
	 * @param value
	 */
	public void putParam(String key, Object value){
		data.put(key, value);
	}
	public void removeParam(){
		data.clear();
	}
	
	//ip겟셋
	public String getIP(){
		return ip;
	}
	public void setIP(String ip){
		this.ip=ip;
	}
	
	//url겟셋
	public URL getURL(){
		return url;
	}
	public void setURL(String url_path){
		try {
			url = new URL(ip+"/"+url_path);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
	public String getApi(){
		String json=null;
		try {
			httpConn = url.openConnection();
			httpConn.setDoOutput(true); // <-- 이것이 핵심입니다.
			httpConn.setUseCaches(false);
			out = new PrintWriter(httpConn.getOutputStream());
			
			System.out.println("data size : "+data.size());
			out.print(url_encoding(data));
			out.flush();

			InputStream is = httpConn.getInputStream();
			in = new BufferedReader(new InputStreamReader(is), 8 * 1024);

			String line = null;
			StringBuilder sb = new StringBuilder(); 
			while ((line = in.readLine()) != null) {
				System.out.println(line);
				sb.append(line);
			}
			json = sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (out != null){
				try {
					out.close();
				} catch (Exception e) {}
			}
			if (in != null){
				try {
					in.close();
				} catch (Exception e) {}
			}		
		}
		
		//위의 결과로 끝나고 밑에는 파라미터 리셋시키는 부분
		data.clear();
		url=null;
		return json;
	}
}