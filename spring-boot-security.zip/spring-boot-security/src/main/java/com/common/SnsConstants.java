package com.common;


/**
 * 공통 상수 <br/>
 * 
 */

public class SnsConstants {
	//Spring security 관련
	public static final String SECURITY_LOGIN_URL = "/user/login";
	public static final String SECURITY_LOGIN_PAGE_URL = "/test/loginPage.do";
	public static final String SECURITY_LOGOUT_URL = "/user/logout";
	public static final String SECURITY_NOAUTH_PAGE_URL = "/user/authFail.do";
	public static final String SECURITY_LOGIN_ID_PARAM = "username";
	public static final String SECURITY_LOGIN_PWD_PARAM = "password";

	public static final String USER_ERROR = "0";
	public static final String USER_NOTFOUND = "1";
	public static final String USER_ID_DUPLICATE = "2";
	public static final String USER_PWD_NOTMATCH = "3";
	
	//기타 공통
	public static final String TEMP_LOC = "/tmp/";
	public static final String S3_SERVER_PATH = "s3.ap-northeast-2.amazonaws.com";	//S3 저장소 주소
	public static final String AES_KEY_STRING = "1111111111111111"; 				//AES 암호화 키 16 bit
	public static final String SIGNATURE_KEY = "JWT_KEY";							//jwt 비교용 암호 키
	public static final Integer EXPIRED_MINUTE = 120;								//jwt 만료시간(분)
	public static final Integer REFRESH_EXPIRED_DATE = 30;							//jwt 리프레시 만료일(일)
}
