package com.common.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;

@Component
@Aspect
@Order(Ordered.LOWEST_PRECEDENCE)
public class RequestProcessAspect {
	protected Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Before("restRequestMapping()")
	public void beforeRestController(JoinPoint jp) throws Throwable {
		for(Object obj : jp.getArgs()){
			if(obj instanceof BindingResult){
				BindingResult result = (BindingResult)obj;
				if(result.hasErrors()){
					throw new BindException(result);
				}
			}else if(obj instanceof ModelMap){ // 메소드의 파라미터 값을 모델에서 지워 주기 위해 
				ModelMap modelMap= (ModelMap)obj;
				modelMap.clear();
			}
		}
	}
	
	@After("restRequestMapping()")
	public void afterRestController(JoinPoint joinPoint) {
		
		for (Object arg : joinPoint.getArgs()) {
			if (arg instanceof ModelMap) {
				ModelMap model = (ModelMap) arg;
				if (!model.containsAttribute("status")) {
					model.addAttribute("status", 0);
				}
			}
		}
	}
	
	@Before("requestMapping()")
	public void beforeController(JoinPoint jp) throws Throwable {
		
		for(Object obj : jp.getArgs()){
			if(obj instanceof BindingResult){
				BindingResult result = (BindingResult)obj;
				if(result.hasErrors()){
					throw new BindException(result);
				}
			}else if(obj instanceof ModelMap){ // 메소드의 파라미터 값을 모델에서 지워 주기 위해 
				ModelMap modelMap= (ModelMap)obj;
				modelMap.clear();
			}
		}
	}
	
	@After("requestMapping()")
	public void afterController(JoinPoint joinPoint) {
		
		for (Object arg : joinPoint.getArgs()) {
			if (arg instanceof ModelMap) {
				ModelMap model = (ModelMap) arg;
				if (!model.containsAttribute("status")) {
					model.addAttribute("status", 0);
				}
			}
		}
	}

	@AfterReturning(pointcut = "restRequestMapping()", returning = "result")
	public void afterRestControllerReturning(JoinPoint joinPoint, Object result) {
		logger.info("Method : " + joinPoint.getSignature().getName());
	}

	@AfterThrowing(pointcut = "restRequestMapping()", throwing = "error")
	public void afterRestControllerThrowing(JoinPoint joinPoint, Throwable error) {
		logger.info("Method : " + joinPoint.getSignature().getName());
		logger.debug("Exception : " + error);
	}
	
	
	@Pointcut("controller() && @annotation(org.springframework.web.bind.annotation.RequestMapping)")
	public void requestMapping() {
	}
	
	@Pointcut("execution(public * com..controller..*Controller.*(..)) && @target(org.springframework.stereotype.Controller)")
	public void controller() {
	}
	
	@Pointcut("restController() && @annotation(org.springframework.web.bind.annotation.RequestMapping)")
	public void restRequestMapping() {
	}
	
	@Pointcut("execution(public * com..controller..*Controller.*(..)) && @target(org.springframework.web.bind.annotation.RestController)")
	public void restController() {
	}
}
