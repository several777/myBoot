package com.config;

import java.io.IOException;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@Configuration
@MapperScan(annotationClass=com.config.Mapper.class, basePackages="com.operation.dao", sqlSessionFactoryRef="sqlSessionFactoryBean")
@EnableTransactionManagement
public class DatabaseConfig {
	@Autowired
    ApplicationContext applicationContext;
			
	@Bean
	public DataSource dataSource() {
	  DriverManagerDataSource dataSource = new DriverManagerDataSource();
	  dataSource.setDriverClassName("com.mysql.jdbc.Driver");
	  dataSource.setUrl("jdbc:mysql://localhost:3306/test");
	  dataSource.setUsername("root");
	  dataSource.setPassword("123123");
	  return dataSource;
	}
	
	@Bean
	public PlatformTransactionManager transactionManager() {
	  return new DataSourceTransactionManager(dataSource());
	}
	
	@Bean
	public SqlSessionFactoryBean sqlSessionFactoryBean(DataSource dataSource,
	   ApplicationContext applicationContext) throws IOException {

	  SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();

	  factoryBean.setDataSource(dataSource);
	  factoryBean.setTypeAliasesPackage("com.operation.model");//ResultType Aliase
	  factoryBean.setConfigLocation(applicationContext.getResource("classpath:META-INF/mybatis/mybatis-config.xml"));
	  factoryBean.setMapperLocations(applicationContext.getResources("classpath:META-INF/mybatis/mapper/**/*.xml"));

	  return factoryBean;
	}
	
	@Bean
	public SqlSessionTemplate sqlSessionTemplate(SqlSessionFactory sqlSessionFactory) {
	      return new SqlSessionTemplate(sqlSessionFactory);
	}
}
	
	
