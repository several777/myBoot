package com.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.common.SnsConstants;
import com.operation.security.AuthenticationTokenProcessingFilter;
import com.operation.security.CustomAuthenticationProvider;
import com.operation.security.RestAuthenticationEntryPoint;
import com.operation.security.RestLoginFailureHandler;
import com.operation.security.RestLoginSuccessHandler;
import com.operation.security.RestLogoutSuccessHandler;
import com.operation.security.paramExtra.ExtraParamSource;
import com.operation.service.UserService;

@Configuration
@EnableGlobalMethodSecurity(securedEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {
     
     @Autowired 
     UserService userService;
     
     @Autowired
     CustomAuthenticationProvider customAuthenticationProvider;
     
     @Autowired
     private RestAuthenticationEntryPoint restAuthenticationEntryPoint;

     @Autowired
     private RestLoginSuccessHandler restLoginSuccessHandler;

     @Autowired
     private RestLogoutSuccessHandler restLogoutSuccessHandler;

     @Autowired
     private RestLoginFailureHandler restLoginFailureHandler;
     
     @Autowired
     private ExtraParamSource extraParamSource;
     
     @Override
     public void configure(WebSecurity web) throws Exception {
         web.ignoring().antMatchers("*.jsp", "/WEB-INF/views/**");								//해당 url 시큐리티 NONE으로 설정. js, images, css는 디폴트로 되어있어서 안해도 된다.
     }
     
     @Override
     protected void configure(HttpSecurity http) throws Exception {
          http
	          .csrf().disable()
	          .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()		//세션폴리시 - STATELESS(REST)
	          .exceptionHandling().authenticationEntryPoint(restAuthenticationEntryPoint).and()		//인증 익셉션 핸들링
	          .authorizeRequests()
	            	.antMatchers(HttpMethod.OPTIONS, "/**").permitAll()							
	            	.antMatchers("/**").permitAll()   												//모든거 풀어놓고 어노테이션으로 제어
	            	//.antMatchers("/resources/**", "/test/**", "/user/login").permitAll()			//모든거 제어하고 해당 주소에 대해 모두 권한 부여
                    //.anyRequest().authenticated()
                    .and()
	          //.requiresChannel().anyRequest().requiresSecure().and()  				//ssl 사용 시 Http 요청을 https로 전환함
              //.portMapper().http(8080).mapsTo(8443).and()								//ssl 사용 시 Http 요청을 https로 전환함
	          .formLogin()
	          	  .loginPage(SnsConstants.SECURITY_LOGIN_PAGE_URL)						//로그인 처리하는 페이지 주소
	              .loginProcessingUrl(SnsConstants.SECURITY_LOGIN_URL)					//로그인 처리하는 API 주소
	              .successHandler(restLoginSuccessHandler)								//성공 핸들링
	              .failureHandler(restLoginFailureHandler)								//실패 핸들링
	              .authenticationDetailsSource(extraParamSource)						//로그인시 추가 파라메터 받기 위해
	              .usernameParameter(SnsConstants.SECURITY_LOGIN_ID_PARAM)				//커스텀 유저 이름
	              .passwordParameter(SnsConstants.SECURITY_LOGIN_PWD_PARAM)				//커스텀 유저 패스워드
	              .permitAll()
	              .and()
	          .logout()
	              .logoutUrl(SnsConstants.SECURITY_LOGOUT_URL)							//로그아웃 시도 API 주소
	              .logoutSuccessHandler(restLogoutSuccessHandler)
	              .invalidateHttpSession(true)
	              .deleteCookies("JSESSIONID")
	              .permitAll()
	              .and()
	          .addFilterBefore(new AuthenticationTokenProcessingFilter(userService), 
	        		  UsernamePasswordAuthenticationFilter.class);
     }
 
 
     @Override
     protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    	 auth.authenticationProvider(customAuthenticationProvider);
     }
     
     @Bean
     @Override
     public AuthenticationManager authenticationManagerBean() throws Exception {
          return super.authenticationManagerBean();
     }
}
