package com.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.accept.ContentNegotiationManager;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.resource.PathResourceResolver;
import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.UrlBasedViewResolver;

import com.common.interceptor.RequestInterceptor;
import com.resolver.JsonViewResolver;

@Configuration
@EnableWebMvc
public class WebMvcConfig extends WebMvcConfigurerAdapter {


    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new RequestInterceptor()).addPathPatterns("/**");
    }
    
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        //registry.addViewController("/error/default").setViewName("static/templates/error/default.html");
        //registry.addViewController("/error/400").setViewName("static/templates/error/400.html");
        //registry.addViewController("/error/404").setViewName("static/templates/error/404.html");
    }
    
    private static final String[] RESOURCE_LOCATIONS = {
        "classpath:/static/"
    };

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
	    registry
	    .addResourceHandler("/**")
	    .addResourceLocations(RESOURCE_LOCATIONS)
	    .setCachePeriod(3600)
	    .resourceChain(true)
	    .addResolver(new PathResourceResolver());
	}

    @Override
    public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
    		configurer.ignoreAcceptHeader(true).
    			defaultContentType(MediaType.APPLICATION_JSON).	//기본 확장자 없는 요청은 JSON으로 처리
                mediaType("do", MediaType.TEXT_HTML);			//.do 요청은 HTML으로 처리
    }

    //확장자를 통해 데이터 내려줌
    @Bean
    public ViewResolver contentNegotiatingViewResolver(
            ContentNegotiationManager manager) {

        ContentNegotiatingViewResolver resolver = new ContentNegotiatingViewResolver();
        resolver.setContentNegotiationManager(manager);
        List<ViewResolver> resolvers = new ArrayList<ViewResolver>();

        resolvers.add(jsonViewResolver());
        resolvers.add(viewResolver());

        resolver.setViewResolvers(resolvers);
        return resolver;
    }

    //JSP
    @Bean
    public UrlBasedViewResolver viewResolver() {
        UrlBasedViewResolver resolver = new UrlBasedViewResolver();
        resolver.setPrefix("/WEB-INF/views/");
        resolver.setSuffix(".jsp");
        resolver.setViewClass(JstlView.class);
        return resolver;
    }
    
    //JSON
    @Bean
    public ViewResolver jsonViewResolver() {
        return new JsonViewResolver();
    }

    /*
     * 상위 분기 한번에 합친것 인데 추후 더 나뉠것을 대비하여 위에 나눈걸로 사용
    @Override
    public void configureViewResolvers(ViewResolverRegistry registry) {
    	MappingJackson2JsonView view = new MappingJackson2JsonView();
        view.setPrettyPrint(true);
        
    	registry.jsp("/WEB-INF/views/", ".jsp");
        registry.enableContentNegotiation(view);
    }*/
}
