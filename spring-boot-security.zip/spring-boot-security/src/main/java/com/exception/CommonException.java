package com.exception;

public class CommonException extends RuntimeException{
	private String message;
	private int code;
	
	public CommonException(SnsResultCode code){
		super(code.message());
		this.message = code.message();
		this.code = code.value();
		//this.printStackTrace();
	}
	
	public String getMessage(){
		return message;
	}
	
	public int getCode(){
		return code;
	}
}
