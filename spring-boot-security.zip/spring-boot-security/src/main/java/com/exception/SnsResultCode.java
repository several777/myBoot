package com.exception;


public enum SnsResultCode {
	/** 성공 */	
	SUCCESS(0, "common.success")
	/** 성공 */	
	
	,FAIL(1, "common.fail")
	
	/*
	 * Common errors (1xx)
	 */

	/** 서버 내부 오류 */
	, INTERNAL_ERROR(100,  "common.internal")

	/** 알 수 없는 오류 */
	, RUNTIME_ERROR(101,  "common.unknown")

	/** 데이타베이스 접속 오류 */
	, DATABASE_ERROR(102, "common.database")

	/** 파라미터 오류 */
	, PARAMETER_ERROR(103,  "파라메타 오류")
	
	/** 로그인 실패 */
	, LOGIN_FAIL(104,  "로그인 실패")
	
	/** 권한 없음 */
	, NO_AUTH(105,  "권한 없음")
	
	/** 토큰에 필수정보 없음 */
	, TOKEN_NEED_NECESSARY_INFO(106,  "토큰에 필수정보 없음")
	
	/** 만료된 토큰 */
	, TOKEN_EXPIRED(107,  "만료된 토큰")
	
	/** 토큰 인증 에러. */
	, TOKEN_AUTH_FAIL(108,  "토큰 인증 에러.")
	
	/** 토큰 길이 오류. */
	, TOKEN_LENGTH_ERROR(109,  "토큰 길이 오류.")
	
	/** 토큰 비교중 에러 */
	, TOKEN_EXCEPTION(110,  "토큰 비교중 에러")
	
	/** 잘못된 토큰을 넣었다. */
	, TOKEN_KIND_ERROR(111,  "잘못된 토큰을 넣었다.")
	
	
	
	
	
	
	
	
	/** 사용할수 없는 값입니다. */
	, VALIDATION_ERROR(700,  "사용할수 없는 값입니다.")
	;

	
	
	/**
	 * 결과 코드
	 */
	private final int value;

	/**
	 * 메시지 코드
	 */
	private final String message;
	
	/**
	 * 결과 코드
	 */
	public int value() {
		return this.value;
	}

	/**
	 * 메시지 코드
	 */
	public String message() {
		return message;
	}
	
	private SnsResultCode(int value, String message) {
		this.value = value;
		this.message = message;
	}
}
