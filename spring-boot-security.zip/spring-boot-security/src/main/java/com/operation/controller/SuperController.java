package com.operation.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.exception.CommonException;
import com.exception.SnsResultCode;

/**
 * Handles requests for the application home page.
 */
public class SuperController {
	protected Logger logger = LoggerFactory.getLogger(this.getClass());
	public Logger getLogger() {
		return logger;
	}

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	// 파라마처 체크
	public void checkParameter(Object obj) {
		if (obj == null) {
			throw new CommonException(SnsResultCode.PARAMETER_ERROR);
		}
		else if(obj instanceof String){
			if (obj == null
					|| obj.equals("")) {
				throw new CommonException(SnsResultCode.PARAMETER_ERROR);
			}
		}
	}
}
