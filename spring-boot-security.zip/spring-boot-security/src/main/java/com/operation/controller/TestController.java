package com.operation.controller;

import java.io.File;
import java.io.IOException;

import javax.annotation.Resource;

import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.common.SnsConstants;
import com.operation.form.UserForm;
import com.operation.service.AsyncService;
import com.operation.service.TestService;

@Controller
@RequestMapping(value = "/test")
public class TestController extends SuperController{
	@Resource
	TestService testService;
	
	@Resource
	AsyncService asyncService;
	
	//로그인,검증테스트
	@RequestMapping(value = "/loginPage.do", method = RequestMethod.GET)
	public String testLogin(ModelMap model, UserForm form){
		return "login";
	}
	
	//트렌젝션 테스트
	@RequestMapping(value = "/call", method = RequestMethod.GET)
	public void callTest(ModelMap model, UserForm form){
		testService.testCall(form.getName());
	}
	
	//비동기 테스트
	@RequestMapping(value = "/async", method = RequestMethod.GET)
	public void testAsync(ModelMap model, UserForm form){
		for (int i = 0; i < 3; i++) {
			asyncService.print(i);
		}
	}
	
	//권한없음 페이지 테스트
	@RequestMapping(value = SnsConstants.SECURITY_NOAUTH_PAGE_URL, method = RequestMethod.GET)
	public String t1(ModelMap model, UserForm form){
		return "test_noauth";
	}
	
	//파일업로드 멀티파트 받나 테스트
	@RequestMapping(value = "/fileUploadTest", method = RequestMethod.POST)
	public void fileUploadTest(ModelMap model, UserForm form) throws IOException{
		System.out.println(form.getUpload_file());
		if(form.getUpload_file() == null){
			return;
		}
		logger.info("업로드 하려는 파일의 용량 : " + form.getUpload_file().getSize());
		File convFile = new File(SnsConstants.TEMP_LOC + form.getUpload_file().getOriginalFilename()); 
		form.getUpload_file().transferTo(convFile);
	}
	
	//유저생성 테스트
	@RequestMapping(value = "/createUser", method = RequestMethod.GET)
	public void testCreateUser(ModelMap model, UserForm form){
		testService.createUser(form);
	}
	
	//포스트 테스트
	@Secured({"ROLE_USER"})
	@RequestMapping(value = "/postTest", method = RequestMethod.POST)
	public void postTest(ModelMap model, UserForm form){
		System.out.println("POST");
	}
	
	
	//겟 테스트
	@Secured({"ROLE_USER"})
	@RequestMapping(value = "/getTest", method = RequestMethod.GET)
	public void getTest(ModelMap model, UserForm form){
		System.out.println("GET");
	}
}
