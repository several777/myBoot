package com.operation.controller;


import javax.annotation.Resource;

import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.operation.form.UserForm;
import com.operation.model.UserDetailsModel;
import com.operation.service.UserService;

@Controller
public class UserController extends SuperController{
	@Resource
	UserService userService;
	
	@Secured({"ROLE_USER"})
	@RequestMapping(value = "/verify/token", method = RequestMethod.GET)
	public void verifyToken(Authentication auth, ModelMap model, UserForm form){
		checkParameter(form.getLogin_token());
		userService.verifyToken(model);
	}
	
	@Secured({"ROLE_REFRESH"})
	@RequestMapping(value = "/refresh/token", method = RequestMethod.GET)
	public void refreshToken(Authentication auth, ModelMap model){
		if(auth!=null){
			UserDetailsModel info = (UserDetailsModel)auth.getPrincipal();
			userService.refreshToken(model, info);
		}
	}
}
