package com.operation.controllerException;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import com.common.interceptor.RequestInterceptor;
import com.exception.CommonException;
import com.exception.SnsResultCode;

@RestController
@ControllerAdvice
public class ControllerAdviceHandler {
	
	private Logger logger = LoggerFactory.getLogger(RequestInterceptor.class);
	
	@Autowired
	private MessageSource messageSource;
	
	/**
	 * 사용자 지정한 익셉션 발생시 메시지, 코드 내려주기
	 */
	@ExceptionHandler(CommonException.class)
	public Map<String,Object> handleCommonException(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception error) {
		Map<String,Object> map = new HashMap<String, Object>();
		if (error instanceof BindException) {
			error.getMessage();
			map.put("error", error.getMessage());
			logger.info("\nerror : " +  error.getMessage());
			error.printStackTrace();
		}else if (error instanceof CommonException) {
			CommonException userError = (CommonException) error;
			map.put("status", userError.getCode());
			map.put("error", userError.getMessage());
			logger.info("\nerror : " + userError.getMessage() + ", status : " + userError.getCode());
			//error.printStackTrace();
		}else if (error instanceof Exception) {
			error.getMessage();
			map.put("status", SnsResultCode.DATABASE_ERROR.value());
			map.put("error", error.getMessage());
			logger.info("\nerror : " + error.getMessage() + ", status : " + SnsResultCode.DATABASE_ERROR.value());
			error.printStackTrace();
		}
		
		return map;
	}
	
	public String getMessage(String message) {
		String string = messageSource.getMessage(message, null, "디폴트 오류",  // message : common.duplicate.user
				null);	
		
		return string;
	}

	public String getMessage() {
		String string = messageSource.getMessage("common.unknown", null, "알 수 없는 오류",
				null);
		return string;
	}
}
