package com.operation.dao;

import com.config.Mapper;

@Mapper
public interface TestDao {
	void testUpdateUser(String name);
}
