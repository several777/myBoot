package com.operation.dao;

import java.util.List;

import com.config.Mapper;
import com.operation.form.UserForm;
import com.operation.model.UserDetailsModel;
import com.operation.model.UserModel;

@Mapper
public interface UserDao {
	UserDetailsModel readUser(String username);
	UserDetailsModel readUserFromSeq(Integer userseq);
	UserDetailsModel readUserNormalLogin(UserForm form);
	List<UserDetailsModel> readAuthority(String username);
	List<UserDetailsModel> readAuthorityFromSeq(Integer userseq);
	void createUser(UserForm form);
    void createAuthority(UserForm form);
    void deleteUser(UserForm form);
    void deleteAuthority(UserForm form);
    UserDetailsModel checkRefreshToken(UserForm form);
    UserModel getUserInfo(Integer userseq);
    void saveRefreshToken(UserForm form);
}
