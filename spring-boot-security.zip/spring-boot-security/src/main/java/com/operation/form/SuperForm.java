package com.operation.form;

import org.springframework.web.multipart.MultipartFile;

public class SuperForm {
	private Integer refresh_token_expired;
	private MultipartFile upload_file;
	
	public Integer getRefresh_token_expired() {
		return refresh_token_expired;
	}

	public void setRefresh_token_expired(Integer refresh_token_expired) {
		this.refresh_token_expired = refresh_token_expired;
	}

	public MultipartFile getUpload_file() {
		return upload_file;
	}

	public void setUpload_file(MultipartFile upload_file) {
		this.upload_file = upload_file;
	}
	
}
