package com.operation.security;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.GenericFilterBean;

import com.operation.form.UserForm;
import com.operation.model.UserDetailsModel;
import com.operation.service.UserService;
import com.util.security.JWTUtils;


public class AuthenticationTokenProcessingFilter extends GenericFilterBean {
    private UserService userAuthService;
    
    public AuthenticationTokenProcessingFilter(UserService userAuthService) {
    	this.userAuthService = userAuthService;
	}

    @SuppressWarnings("unchecked")
	@Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = this.getAsHttpRequest(request);

        String loginToken = this.loginTokenFromRequest(httpRequest);
        String refreshToken = this.refreshTokenFromRequest(httpRequest);
        
        if (refreshToken != null){
        	//토큰 정보 추출
        	Map<String,Object> resultObject = JWTUtils.refreshToken(refreshToken);
    		
    		int status = (Integer)resultObject.get("return");//추출 결과 스테이터스
    		if(status == 0){
    			int user_seq = (Integer)resultObject.get("user_seq");
    			List<String> auth_list = (List<String>)resultObject.get("auth_list");
    			
    			UserForm form = new UserForm();
    			form.setUser_seq(user_seq);
    			form.setRefresh_token(refreshToken);
    			
    			//토큰 체크 from DB
    			UserDetailsModel user = userAuthService.checkRefreshToken(form);
            	if(user == null){
            		errorResponse(-7, response);
            	}else{
            		user.setAuthorities(setAuthorities(auth_list));
            		
            		logger.debug("REFRESH 토큰 비교 성공, 유저 권한 : " + user.getAuthorities());
                    UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(httpRequest));
                    SecurityContextHolder.getContext().setAuthentication(authentication);
            	}
    		}else{
    			errorResponse(status, response);
    		}
        }else if (loginToken != null) {
        	//토큰 정보 추출
    		Map<String,Object> resultObject = JWTUtils.checkToken(loginToken);
    		
    		int status = (Integer)resultObject.get("return");//추출 결과 스테이터스
    		if(status == 0){
    			int user_seq = (Integer)resultObject.get("user_seq");
    			List<String> auth_list = (List<String>)resultObject.get("auth_list");
    			
    			UserDetailsModel user = new UserDetailsModel();
    			user.setAuthorities(setAuthorities(auth_list));		//principal에 필수 권한 넣기
    			user.setUser_seq(user_seq);							//principal에 포함할 값들 넣기
    			
    			if(user != null){
        			logger.debug("ACCESS 토큰 비교 성공, 유저 권한 : " + user.getAuthorities());
                    UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(httpRequest));
                    SecurityContextHolder.getContext().setAuthentication(authentication);
        		}
    		}else{
    			errorResponse(status, response);
    		}
        }

        chain.doFilter(request, response);
    }

    private void errorResponse(int status, ServletResponse response) throws IOException, ServletException {
    	response.setContentType("application/json");
        response.setCharacterEncoding("utf-8");
        
        String data = "";
    	if(status == -1){			logger.info("토큰에 필수정보 없음");
            data = "{\"status\" : 106 , \"message\" : \"토큰에 필수정보 없음.\" }";
        }else if(status == -2){		logger.info("만료된 토큰입니다");
            data = "{\"status\" : 107 , \"message\" : \"만료된 토큰입니다.\" }";
        }else if(status == -3){		logger.info("토큰 인증 에러.");
            data = "{\"status\" : 108 , \"message\" : \"토큰 인증 에러.\" }";
        }else if(status == -4){		logger.info("토큰 길이 오류");
            data = "{\"status\" : 109 , \"message\" : \"토큰 길이 오류.\" }";
        }else if(status == -5){		logger.info("토큰 비교중 에러");
            data = "{\"status\" : 110 , \"message\" : \"토큰 비교중 에러.\" }";
        }else if(status == -6){		logger.info("잘못된 토큰을 넣었습니다.");
            data = "{\"status\" : 111 , \"message\" : \"잘못된 토큰을 넣었습니다.\" }";
        }else if(status == -7){		logger.info("리프레시 토큰 오류");
            data = "{\"status\" : 112 , \"message\" : \"리프레시 토큰 오류.\" }";
        }
    	
    	PrintWriter out = response.getWriter();		out.print(data);	out.flush();	out.close();
    }

    private HttpServletRequest getAsHttpRequest(ServletRequest request) {
        if (!(request instanceof HttpServletRequest)) {
            throw new RuntimeException("Expecting an HTTP request");
        }

        return (HttpServletRequest) request;
    }
    
    public Collection<GrantedAuthority> setAuthorities(List<String> auth_list) {
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        for (int j = 0; j < auth_list.size(); j++) {
        	String authority = auth_list.get(j);
            authorities.add(new SimpleGrantedAuthority(authority));
		}
        
        return authorities;
    }


    private String loginTokenFromRequest(HttpServletRequest httpRequest) {
        //String authToken = httpRequest.getHeader("login_token");//헤더에 담는 방식
    	String authToken = httpRequest.getParameter("login_token");
        return authToken;
    }
    
    private String refreshTokenFromRequest(HttpServletRequest httpRequest) {
        //String authToken = httpRequest.getHeader("login_token");//헤더에 담는 방식
    	String refreshToken = httpRequest.getParameter("refresh_token");
        return refreshToken;
    }
    
    public void Test(){
    	//서버관련 요청이 필터에서 필요시 서비스 사용
    	userAuthService.readUser(0);
    }
}