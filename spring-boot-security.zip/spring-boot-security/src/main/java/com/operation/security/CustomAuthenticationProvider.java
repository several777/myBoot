package com.operation.security;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import com.common.SnsConstants;
import com.operation.model.UserDetailsModel;
import com.operation.security.paramExtra.ExtraParam;
import com.operation.service.UserService;
import com.util.security.AES128Cipher;

//커스텀 로그인인증처리 제공자
@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {
    private static final Logger logger = LoggerFactory.getLogger(CustomAuthenticationProvider.class);
    
    @Resource
    UserService userService;
    
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        String password = (String) authentication.getCredentials();
        
        String custom_param = ((ExtraParam)authentication.getDetails()).getCustom_parameter();
        if(custom_param!=null){
        	logger.debug("커스텀 파라미터  : " + custom_param);
        }
        
        UserDetailsModel user = null;
        
        try {
        	if(password.equals("")){
        		logger.info("비밀번호 없는 로그인 - 페이스북, 등 SNS 로그인의 경우");
        		/*
        		user = userService.readUser(username);
                if(user == null){
                 	logger.info("회원 가입 후 로그인 처리한다.");
                 	//회원가입 처리
                 	//xx.signup
                 	
                 	//로그인 처리
                 	//user = userAuthService.readUser(id);
                }else{
                 	logger.info("회원 가입 없이 로그인 처리 한다.");
                }*/
        	}else{
        		logger.info("일반 로그인");
        		
        		user = userService.readUser(username);
        		
        		if(user != null){
        			String input_pass = AES128Cipher.encrypt(password);
            		if(!input_pass.equals(user.getPassword())){
            			 throw new BadCredentialsException(SnsConstants.USER_PWD_NOTMATCH);
            		}
        		}
        	}
            
        	if(user == null){
        		throw new BadCredentialsException(SnsConstants.USER_NOTFOUND);
        	}
        } catch(BadCredentialsException e) {
        	//커스텀 값으로 통합
            logger.info(e.toString());
            throw new BadCredentialsException(e.getMessage());
        } catch(Exception e) {
            logger.info(e.toString());
            throw new RuntimeException(e.getMessage());
        }

        return new UsernamePasswordAuthenticationToken(user, password, user.getAuthorities());
    }

    @Override
    public boolean supports(Class<?> arg0) {
        return true;
    }
}
