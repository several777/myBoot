package com.operation.security;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import com.common.SnsConstants;

@Component
public class RestAuthenticationEntryPoint implements AuthenticationEntryPoint {
	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {
		String accept = request.getHeader("accept");
		
		if( accept.indexOf("html") > -1 ) {
			response.sendRedirect(SnsConstants.SECURITY_NOAUTH_PAGE_URL);
        } else{
        	response.setContentType("application/json");
            response.setCharacterEncoding("utf-8");
            
            String data = "{\"status\" : 105 , \"message\" : \"권한 없음.\" }";

            PrintWriter out = response.getWriter();
            out.print(data);
            out.flush();
            out.close();
        }
	}
}
