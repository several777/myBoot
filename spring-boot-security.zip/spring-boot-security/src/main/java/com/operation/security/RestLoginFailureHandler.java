package com.operation.security;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import com.common.SnsConstants;

@Component
public class RestLoginFailureHandler implements AuthenticationFailureHandler {
	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {
         response.setContentType("application/json");
         response.setCharacterEncoding("utf-8");
         
         String data = "";
         if(exception.getMessage().equals(SnsConstants.USER_ERROR)){
        	 data = "{\"status\" : 104 , \"message\" : \"알수없는 오류.\" }";
         }else if(exception.getMessage().equals(SnsConstants.USER_NOTFOUND)){
        	 data = "{\"status\" : 104 , \"message\" : \"없는 유저입니다.\" }";
         }else if(exception.getMessage().equals(SnsConstants.USER_ID_DUPLICATE)){
        	 data = "{\"status\" : 104 , \"message\" : \"중복된 아이디입니다.\" }";
         }else if(exception.getMessage().equals(SnsConstants.USER_PWD_NOTMATCH)){
        	 data = "{\"status\" : 104 , \"message\" : \"비밀번호가 일치하지 않습니다.\" }";
         }//커스텀 에러 값 추가

         PrintWriter out = response.getWriter();
         out.print(data);
         out.flush();
         out.close();
	}
}
