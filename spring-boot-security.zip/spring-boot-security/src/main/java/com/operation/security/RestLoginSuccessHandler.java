package com.operation.security;
import java.io.IOException;
import java.io.PrintWriter;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.operation.model.UserDetailsModel;
import com.operation.service.UserService;
import com.util.security.JWTUtils;

@Component
public class RestLoginSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {
	@Resource
	private UserService loginService;

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		logger.info("핸들러 - 로그인");

		UserDetailsModel info = (UserDetailsModel)authentication.getPrincipal();
        String login_token = JWTUtils.createToken(info);
        String refresh_token = JWTUtils.createRefreshToken(info);
        logger.debug("login_token : " + login_token);
        logger.debug("refresh_token : " + refresh_token);
        
    	loginService.setRefreshToken(info.getUser_seq(), refresh_token);
        
         response.setContentType("application/json");
         response.setCharacterEncoding("utf-8");

         String data = "{\"status\" : 0 , \"message\" : \"로그인하였습니다.\", "
         		+ "\"login_token\" : \""+login_token+"\", \"refresh_token\" : \""+refresh_token+"\" }";

         PrintWriter out = response.getWriter();
         out.print(data);
         out.flush();
         out.close();
	}
}
