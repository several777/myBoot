package com.operation.security;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.stereotype.Component;

@Component
public class RestLogoutSuccessHandler extends SimpleUrlLogoutSuccessHandler {

	@Override
	public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
			throws IOException, ServletException {
		logger.info("핸들러 - 로그아웃");
		
		//로그아웃 처리 필요시 처리
        
         response.setContentType("application/json");
         response.setCharacterEncoding("utf-8");
         
         String data = "{\"status\" : 0 , \"message\" : \"로그아웃하였습니다.\" }";
         PrintWriter out = response.getWriter();
         out.print(data);
         out.flush();
         out.close();
	}
}
