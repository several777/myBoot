package com.operation.service;

import com.operation.form.UserForm;

public interface TestService{
	void testCall(String test);
	void createUser(UserForm form);
    void deleteUser(UserForm form);
}