package com.operation.service;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.ui.ModelMap;

import com.operation.form.UserForm;
import com.operation.model.UserDetailsModel;

public interface UserService{
	UserDetailsModel checkRefreshToken(UserForm form);
    Collection<GrantedAuthority> getAuthorities(String username);
    Collection<GrantedAuthority> getAuthorities(Integer userseq);
    UserDetailsModel readUser(UserForm form);
    UserDetailsModel readUser(Integer userseq);
    UserDetailsModel readUser(String username);
    void verifyToken(ModelMap model);
    void refreshToken(ModelMap model, UserDetailsModel info);
    void setRefreshToken(Integer user_seq, String refresh_token);
}