package com.operation.serviceimpl;

import java.util.ArrayList;
import java.util.Arrays;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.exception.CommonException;
import com.exception.SnsResultCode;
import com.operation.dao.TestDao;
import com.operation.dao.UserDao;
import com.operation.form.UserForm;
import com.operation.service.TestService;
import com.util.security.AES128Cipher;

@Service
public class TestServiceImpl implements TestService {
	private Logger logger = Logger.getLogger(this.getClass());
	
	@Autowired
	TestDao testDao;
	
	@Autowired
	UserDao userDao;
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
	public void testCall(String test) {
		testDao.testUpdateUser(test);
		
		if(true){
			throw new CommonException(SnsResultCode.FAIL);
		}
	}
	
    @Override
    @Transactional(propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
    public void createUser(UserForm form) {
    	logger.debug("유저 생성 - 테스트용");
		UserForm user = new UserForm();
		
		user.setUsername("test10");
		user.setPassword("pass10");
		user.setAuthority_list(new ArrayList<String>(Arrays.asList("ROLE_USER","ROLE_ADMIN"))); //role 을 붙여줘야한다.
		
		String rawPassword = user.getPassword();
        String encodedPassword = null;
        
		try {
			encodedPassword = AES128Cipher.encrypt(rawPassword);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        user.setPassword(encodedPassword);
        
        userDao.createUser(user);
        userDao.createAuthority(user);
    }

    @Override
    public void deleteUser(UserForm form) {
    	logger.debug("유저 삭제 - 테스트용");
    	userDao.deleteUser(form);
    	userDao.deleteAuthority(form);
    }
}
