package com.operation.serviceimpl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.common.SnsConstants;
import com.operation.dao.UserDao;
import com.operation.form.UserForm;
import com.operation.model.UserDetailsModel;
import com.operation.service.UserService;
import com.util.security.JWTUtils;

@Service
public class UserServiceImpl implements UserService {
	private Logger logger = Logger.getLogger(this.getClass());
	
    @Autowired UserDao userDao;
    
    //유저 이름으로 유저권한 가져오기
    @Override
    public Collection<GrantedAuthority> getAuthorities(String username) {
    	logger.debug("유저 이름으로 유저권한 가져오기");
        List<UserDetailsModel> string_authorities = userDao.readAuthority(username);
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        for (int j = 0; j < string_authorities.size(); j++) {
        	String authority = string_authorities.get(j).getAuthority_name();
            authorities.add(new SimpleGrantedAuthority(authority));
		}
        
        return authorities;
    }
    
    //유저 시큐로 유저권한 가져오기
    @Override
    public Collection<GrantedAuthority> getAuthorities(Integer userseq) {
    	logger.debug("유저 시큐로 유저권한 가져오기");
        List<UserDetailsModel> string_authorities = userDao.readAuthorityFromSeq(userseq);
        List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
        for (int j = 0; j < string_authorities.size(); j++) {
        	String authority = string_authorities.get(j).getAuthority_name();
            authorities.add(new SimpleGrantedAuthority(authority));
		}
        
        return authorities;
    }
    
    //유저 폼안의 이름으로 유저 읽기
    @Override
    public UserDetailsModel readUser(UserForm form) {
    	logger.debug("유저 폼안의 이름으로 유저 읽기");
    	UserDetailsModel user = userDao.readUser(form.getUsername());
    	if(user!=null){
    		user.setAuthorities(getAuthorities(form.getUsername()));
    	}
        return user;
    }
    
    //유저 이름으로 유저 읽기
    @Override
    public UserDetailsModel readUser(String username) {
    	logger.debug("유저 이름으로 유저 읽기");
    	UserDetailsModel user = userDao.readUser(username);
        if(user!=null){
        	user.setAuthorities(getAuthorities(username));
    	}
    	return user;
    }
    
    //유저 시큐로 유저 읽기
    @Override
    public UserDetailsModel readUser(Integer userseq) {
    	logger.debug("유저 시큐로 유저 읽기");
    	UserDetailsModel user = userDao.readUserFromSeq((userseq));
        if(user!=null){
        	user.setAuthorities(getAuthorities(userseq));
    	}
    	return user;
    }
    
    //토큰 리프레쉬
    @Override
    public void refreshToken(ModelMap model, UserDetailsModel info) {
    	logger.debug("토큰 리프레쉬");
    	String refresh_token = JWTUtils.createRefreshToken(info);
    	
    	//리프레시 토큰은 저장
    	setRefreshToken(info.getUser_seq(), refresh_token);
    	
    	//내려줌
		model.addAttribute("refresh_token",refresh_token);
		model.addAttribute("login_token",JWTUtils.createToken(readUser(info.getUser_seq())));
    }
    
    //리프레시 토큰 저장
    @Override
    public void setRefreshToken(Integer user_seq, String refresh_token) {
    	logger.debug("리프레시 토큰 저장");
    	
    	UserForm form = new UserForm();
    	form.setUser_seq(user_seq);
    	form.setRefresh_token(refresh_token);
    	form.setRefresh_token_expired(SnsConstants.REFRESH_EXPIRED_DATE);
    	userDao.saveRefreshToken(form);
    }
    
    //토큰 사용가능 검증 - 테스트용
    @Override
    public void verifyToken(ModelMap model) {
    	logger.debug("토큰 사용가능 검증 - 테스트용");
    	model.addAttribute("message", "ok");
    }
    
    //리프레시토큰 유효성 체크
    @Override
    public UserDetailsModel checkRefreshToken(UserForm form) {
    	logger.debug("리프레시토큰 유효성 체크");
    	return userDao.checkRefreshToken(form);
    }
    
}
