package com.operation.test;

public class TestJava {
/*	public static void main(String[] args) {
    	//iss: 토큰을 발급한 발급자(Issuer)
    	//sub: Claim의 주제(Subject)로 토큰이 갖는 문맥을 의미한다.
    	//aud: 이 토큰을 사용할 수신자(Audience)
    	//exp: 만료시간(Expiration Time)은 만료시간이 지난 토큰은 거절해야 한다.
    	//nbf: Not Before의 의미로 이 시간 이전에는 토큰을 처리하지 않아야 함을 의미한다.
    	//iat: 토큰이 발급된 시간(Issued At)
    	//jti: JWT ID로 토큰에 대한 식별자이다.
    	//claims 으로 그냥 만들어서 해도됨
    	
    	Map<String,Object> claims = new HashMap<String,Object>();
    	claims.put("test", 1234);
    	claims.put("user_seq", 1234);
    	
    	Date dt = new Date();
    	Calendar c = Calendar.getInstance(); 
    	c.setTime(dt); 
    	c.add(Calendar.DATE, 7);
    	dt = c.getTime();
    	
    	String jwtString = Jwts.builder()
    			.setHeaderParam("typ", "JWT")
    			.setHeaderParam("issueDate", System.currentTimeMillis())
    			.setClaims(claims)
    			.setExpiration(dt)
    			.signWith(SignatureAlgorithm.HS512, "keyname")
    			.compact();
    	System.out.println(jwtString);
    	System.out.println(getTokenBody(jwtString));
    	System.out.println(getTokenHeader(jwtString));
	}
    
	public static JwsHeader<?> getTokenHeader(String token) { 
    	return Jwts.parser() 
    	.setSigningKey("keyname") 
    	.parseClaimsJws(token) 
    	.getHeader(); 
    } 

	public static Claims getTokenBody(String token) { 
    	return Jwts.parser() 
    	.setSigningKey("keyname") 
    	.parseClaimsJws(token) 
    	.getBody(); 
    }*/
}
