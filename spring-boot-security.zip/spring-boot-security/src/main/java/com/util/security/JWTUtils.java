package com.util.security;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.security.core.GrantedAuthority;

import com.common.SnsConstants;
import com.operation.model.UserDetailsModel;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwsHeader;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

//JWT 토큰 생성 유틸 클래스
public class JWTUtils {
	//AccessToken 생성
	public static String createToken(UserDetailsModel user){
		Map<String,Object> claims = new HashMap<String,Object>();
		
		//CUSTOM ZONE
		List<String> auth_list = new ArrayList<String>();
    	Iterator<? extends GrantedAuthority> itr = user.getAuthorities().iterator();
        while (itr.hasNext()) { 
        	auth_list.add(itr.next().getAuthority()); 
        }
    	claims.put("user_seq", user.getUser_seq());
    	claims.put("auth_list", auth_list);
    	
    	Date dt = new Date();
    	Calendar c = Calendar.getInstance(); 
    	c.setTime(dt); 
    	c.add(Calendar.MINUTE, SnsConstants.EXPIRED_MINUTE);
    	dt = c.getTime();
    			
		String accessToken = Jwts.builder()
    			.setHeaderParam("type", "accessToken")								//헤더값
    			.setHeaderParam("issueDate", System.currentTimeMillis())			//헤더값
    			.setClaims(claims)													//바디 데이터값
    			.setExpiration(dt)													//만료일
    			.signWith(SignatureAlgorithm.HS512, SnsConstants.SIGNATURE_KEY)		//암호화방식
    			.compact();
		return accessToken;
	}
	
	//refreshToken 생성
	public static String createRefreshToken(UserDetailsModel user){
		Map<String,Object> claims = new HashMap<String,Object>();
		
		List<String> auth_list = Arrays.asList("ROLE_REFRESH");//리프레시 권한만 가지게 설정
    	claims.put("user_seq", user.getUser_seq());
    	claims.put("auth_list", auth_list);
    	
    	Date dt = new Date();
    	Calendar c = Calendar.getInstance(); 
    	c.setTime(dt); 
    	c.add(Calendar.DATE, SnsConstants.REFRESH_EXPIRED_DATE);
    	dt = c.getTime();
    			
		String refreshToken = Jwts.builder()
    			.setHeaderParam("type", "refreshToken")								//헤더값
    			.setHeaderParam("issueDate", System.currentTimeMillis())			//헤더값
    			.setClaims(claims)													//바디 데이터값
    			.setExpiration(dt)													//만료일
    			.signWith(SignatureAlgorithm.HS512, SnsConstants.SIGNATURE_KEY)		//암호화방식
    			.compact();
		return refreshToken;
	}
	
	//accessToken 체크
	@SuppressWarnings("unchecked")
	public static Map<String,Object> checkToken(String token){
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("return", 0);
		try{
			JwsHeader<?> token_header = getTokenHeader(token);
			Claims token_body = getTokenBody(token);
			
			List<String> auth_list = (List<String>)token_body.get("auth_list"); //필수 파람 체크
			Integer user_seq = (Integer)token_body.get("user_seq");	//필수 파람 체크
			String token_type = (String)token_header.get("type");	//토큰 타입 체크
			
			if(user_seq == null || auth_list == null){
				map.put("return", -1);
				return map; 
			}else if(token_type.equals("refreshToken")){
				map.put("return", -6);
				map.put("user_seq", user_seq);
				map.put("auth_list", auth_list);
				return map; 
			}else{
				map.put("return", 0);
				map.put("user_seq", user_seq);
				map.put("auth_list", auth_list);
				return map;
			}
		}catch(io.jsonwebtoken.ExpiredJwtException e){
			map.put("return", -2);
			return map; 
		}catch(io.jsonwebtoken.SignatureException e){
			map.put("return", -3);
			return map; 
		}catch(io.jsonwebtoken.MalformedJwtException e){
			map.put("return", -4);
			return map; 
		}catch(Exception e){
			map.put("return", -5);
			return map; 
		}
	}
	
	//refreshToken 체크
	@SuppressWarnings("unchecked")
	public static Map<String,Object> refreshToken(String token){
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("return", 0);
		try{
			JwsHeader<?> token_header = getTokenHeader(token);
			Claims token_body = getTokenBody(token);

			List<String> auth_list = (List<String>)token_body.get("auth_list"); //필수 파람 체크
			Integer user_seq = (Integer)token_body.get("user_seq");	//필수 파람 체크
			String token_type = (String)token_header.get("type");	//토큰 타입 체크
			System.out.println(token_type);
			if(user_seq == null || auth_list == null){
				map.put("return", -1);
				return map; 
			}else if(token_type.equals("accessToken")){
				map.put("return", -6);
				map.put("user_seq", user_seq);
				map.put("auth_list", auth_list);
				return map; 
			}else{
				map.put("return", 0);
				map.put("user_seq", user_seq);
				map.put("auth_list", auth_list);
				return map;
			}
		}catch(io.jsonwebtoken.ExpiredJwtException e){
			map.put("return", -2);
			return map; 
		}catch(io.jsonwebtoken.SignatureException e){
			map.put("return", -3);
			return map; 
		}catch(io.jsonwebtoken.MalformedJwtException e){
			map.put("return", -4);
			return map; 
		}catch(Exception e){
			e.printStackTrace();
			map.put("return", -5);
			return map; 
		}
	}
    
	public static JwsHeader<?> getTokenHeader(String token) { 
    	return Jwts.parser() 
    	.setSigningKey(SnsConstants.SIGNATURE_KEY) 
    	.parseClaimsJws(token) 
    	.getHeader(); 
    } 

	public static Claims getTokenBody(String token) { 
    	return Jwts.parser() 
    	.setSigningKey(SnsConstants.SIGNATURE_KEY) 
    	.parseClaimsJws(token) 
    	.getBody(); 
    }
}
